﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            FileInfo file = new FileInfo(@"D:\Temp\sample.txt");
            //file.Create();
            StreamWriter w = file.CreateText();
            w.WriteLine(textBox1.Text);
            w.Close();

            ////file.CopyTo(destFileName);
            //file.MoveTo(destFileName);
            //file.Delete();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FileInfo file = new FileInfo(@"D:\Temp\sample.txt");
            StreamReader r = file.OpenText();
            string s = "";

            while ((s = r.ReadLine()) != null)
            {
                textBox1.Text += s;
            }
            r.Close();
        }
    }

}
    
